import $ from 'jquery';


(window as any).$ = (window as any).jQuery = $;